package personal_finance_manager;

public class Main_Driver_Gui {
    public static void main(String[] args) {

        Login_Gui driver_obj = new Login_Gui();
    }
}
