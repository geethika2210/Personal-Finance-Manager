package personal_finance_manager;

import java.io.IOException;

class demo_Caller{
    public static void main(String[] args) throws IOException {
        int userId = 0;
        String name="";
        DashBoard_Gui obj_demo_caller = new DashBoard_Gui(userId,name);
        //Report_form objReportForm = new Report_form(userId);

        //Transaction_form objd = new Transaction_form(userId,name);
      //  Sign_up_Gui obj_S = new Sign_up_Gui();

        //Login_Gui newobj = new Login_Gui();

       // Report_form reportForm =  new Report_form();
    }
}